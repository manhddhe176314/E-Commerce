/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Tu
 */
public class Order {
    
    private int id;
    private Account user;
    private int totalPrice;
    private String note;
    private ShipAddress shipaddress;
    private OrderStatus status;
    private String orderDate;
    private String deliveryDate;

    public Order() {
    }

    public Order(int id, Account user, int totalPrice, String note, ShipAddress shipaddress, OrderStatus status, String orderDate, String deliveryDate) {
        this.id = id;
        this.user = user;
        this.totalPrice = totalPrice;
        this.note = note;
        this.shipaddress = shipaddress;
        this.status = status;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Account getUser() {
        return user;
    }

    public void setUser(Account user) {
        this.user = user;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public ShipAddress getShipaddress() {
        return shipaddress;
    }

    public void setShipaddress(ShipAddress shipaddress) {
        this.shipaddress = shipaddress;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    @Override
    public String toString() {
        return "Orders{" + "id=" + id + ", user=" + user + ", totalPrice=" + totalPrice + ", note=" + note + ", shipaddress=" + shipaddress + ", status=" + status + ", orderDate=" + orderDate + ", deliveryDate=" + deliveryDate + '}';
    }
    
}
