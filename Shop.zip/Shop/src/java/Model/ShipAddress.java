/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Tu
 */
public class ShipAddress {
    private int id;
    private Account user;
    private String fullname;
    private String phoneNum;
    private City city;
    private District district;
    private String addressDetail;
    private boolean isUse;

    public ShipAddress() {
    }

    public ShipAddress(int id, Account user, String fullname, String phoneNum, City city, District district, String addressDetail, boolean isUse) {
        this.id = id;
        this.user = user;
        this.fullname = fullname;
        this.phoneNum = phoneNum;
        this.city = city;
        this.district = district;
        this.addressDetail = addressDetail;
        this.isUse = isUse;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Account getUser() {
        return user;
    }

    public void setUser(Account user) {
        this.user = user;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public District getDistrict() {
        return district;
    }

    public void setDistrict(District district) {
        this.district = district;
    }

    public String getAddressDetail() {
        return addressDetail;
    }

    public void setAddressDetail(String addressDetail) {
        this.addressDetail = addressDetail;
    }

    public boolean isIsUse() {
        return isUse;
    }

    public void setIsUse(boolean isUse) {
        this.isUse = isUse;
    }

    @Override
    public String toString() {
        return "ShipAddress{" + "id=" + id + ", user=" + user + ", fullname=" + fullname + ", phoneNum=" + phoneNum + ", city=" + city + ", district=" + district + ", addressDetail=" + addressDetail + ", isUse=" + isUse + '}';
    }
    
    
}
