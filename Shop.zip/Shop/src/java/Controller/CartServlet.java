/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Dao.CartDAO;
import Dao.CartProductDAO;
import Dao.ProductDAO;
import Dao.ShipAddressDAO;
import Model.Account;
import Model.Cart;
import Model.CartProduct;
import Model.Product;
import Model.ShipAddress;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;

/**
 *
 * @author Tu
 */
public class CartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        doPost(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        switch (action) {
            case "addcart":
                addCart(request, response);
                break;
            case "viewcart":
                viewCart(request, response);
                break;
            case "delProduct":
                deleteProduct(request, response);
                break;
            case "cartcomplete":
                viewCartComplete(request, response);
                break;
            default:
                break;
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void addCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {

            HttpSession session = request.getSession();
            Account user = (Account) session.getAttribute("user");
            if (user != null) {
                

                String productId_String = request.getParameter("productId");
                String amount_String = request.getParameter("amount");

                int productId = Integer.parseInt(productId_String);
                int amount = Integer.parseInt(amount_String);
                ProductDAO product_dao = new ProductDAO();
                Product product = product_dao.selectById(productId);

                CartDAO cart_dao = new CartDAO();

                CartProductDAO cartproduct_dao = new CartProductDAO();

                if (cart_dao.selectByUserId(user.getId()) == null) {
                    cart_dao.insert(new Cart(1, user));
                    cartproduct_dao.insert(new CartProduct(cart_dao.selectByUserId(user.getId()), product, amount));
                } else {
                    cartproduct_dao.insert(new CartProduct(cart_dao.selectByUserId(user.getId()), product, amount));
                }

                String message = "Add product successfully ";
                session.setAttribute("message", message);
                request.getRequestDispatcher("home").forward(request, response);
            } else {
                response.sendRedirect("login");
            }
        } catch (NumberFormatException e) {
            System.out.println(e);
        }
    }

    private void viewCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Account user = (Account) session.getAttribute("user");
        if (user == null) {
            request.getRequestDispatcher("login").forward(request, response);
        } else {
            CartDAO cart_dao = new CartDAO();
            Cart cart = cart_dao.selectByUserId(user.getId());
            if (cart != null) {
                CartProductDAO cartproduct_dao = new CartProductDAO();
                int total = 0;
//                int quantity_total = 0;
                for (CartProduct cartproduct : cartproduct_dao.getByCartId(cart.getId())) {
                    Product p = cartproduct.getProduct();
                    total += p.getSellPrice() * cartproduct.getAmount();
//                    quantity_total += cartproduct.getAmount();
                }
                request.setAttribute("total", total);
                request.setAttribute("listCartProduct", cartproduct_dao.getByCartId(cart.getId()));
                request.getRequestDispatcher("viewCart.jsp").forward(request, response);
            } else {
                String message = "You don't have any product in cart ";
                session.setAttribute("message", message);
                request.getRequestDispatcher("home").forward(request, response);
            }
        }

    }

    private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Account user = (Account) session.getAttribute("user");
        if (user == null) {
            request.getRequestDispatcher("login").forward(request, response);
        } else {
            String cartId_String = request.getParameter("cartId");
            String productId_String = request.getParameter("productId");

            try {
                int cartId = Integer.parseInt(cartId_String);
                int productId = Integer.parseInt(productId_String);

                CartProductDAO cartproduct_dao = new CartProductDAO();
                CartProduct p = cartproduct_dao.getByProIdAndCartId(cartId, productId);
                cartproduct_dao.deleteByCartProduct(p.getCart().getId(), p.getProduct().getProductId());
                viewCart(request, response);
            } catch (NumberFormatException e) {
                System.out.println(e);
            }
        }
    }

    private void viewCartComplete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            Account user = (Account) session.getAttribute("user");
            if (user != null) {
                
                if (user == null) {
                    request.getRequestDispatcher("login").forward(request, response);
                }

                CartDAO cart_dao = new CartDAO();
                CartProductDAO cartproduct_dao = new CartProductDAO();
                Cart cart = cart_dao.selectByUserId(user.getId());
                int total = 0;
                for (CartProduct cartproduct : cartproduct_dao.getByCartId(cart.getId())) {
                    Product p = cartproduct.getProduct();
                    total += p.getSellPrice() * cartproduct.getAmount();
                }
                request.setAttribute("total", total);
                request.setAttribute("listCartProduct", cartproduct_dao.getByCartId(cart.getId()));

                ShipAddressDAO address_dao = new ShipAddressDAO();
                ArrayList<ShipAddress> list_shipAddress = address_dao.getByUserId(user.getId());
                ShipAddress shipaddress1 = new ShipAddress();
                boolean check = false;
                for (ShipAddress shipAddres : list_shipAddress) {
                    if (shipAddres.isIsUse()) {
                        shipaddress1 = new ShipAddress(shipAddres.getId(),
                                shipAddres.getUser(), shipAddres.getFullname(),
                                shipAddres.getPhoneNum(), shipAddres.getCity(),
                                shipAddres.getDistrict(), shipAddres.getAddressDetail(), shipAddres.isIsUse());
                        check = true;
                    }
                }
                if (!list_shipAddress.isEmpty()) {
                    if (check == true) {
                        request.setAttribute("shipaddress", shipaddress1);
                    } else {
                        request.setAttribute("shipaddress", list_shipAddress.get(0));
                    }
                    request.setAttribute("cartId", cart.getId());
                    request.getRequestDispatcher("cartcomplete.jsp").forward(request, response);
                }

            } else {
                request.getRequestDispatcher("login").forward(request, response);
            }
        } catch (Exception e) {
        }
    }
}
