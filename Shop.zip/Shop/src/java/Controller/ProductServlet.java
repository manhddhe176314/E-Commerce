/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Dao.CategoryDAO;
import Dao.ProductDAO;
import Model.Account;
import Model.Category;
import Model.Product;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.InputStream;
import java.util.ArrayList;

/**
 *
 * @author Tu
 */
@MultipartConfig(maxFileSize = 16177216)
public class ProductServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        switch (action) {
            case "viewdetail":
                viewDetail(request, response);
                break;
            case "viewMyProduct":
                viewMyProduct(request, response);
                break;
            case "viewAddProduct":
                viewAddProduct(request, response);
                break;
            case "addProduct":
                addProduct(request, response);
                break;
            case "deleteProduct":
                deleteProduct(request, response);
                break;
            default:
                break;
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void viewDetail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productId_string = request.getParameter("productId");
        try {
            int productId = Integer.parseInt(productId_string);
            ProductDAO product_dao = new ProductDAO();
            Product product = product_dao.selectById(productId);
            request.setAttribute("product", product);
            request.getRequestDispatcher("productDetail.jsp").forward(request, response);
        } catch (NumberFormatException numberFormatException) {
        }
    }

    private void viewMyProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {

            HttpSession session = request.getSession();
            Account user = (Account) session.getAttribute("user");
            if (user != null) {
                

                if (user.getRole().getRoleId() != 2) {
                    String message = "You can't view this screen";
                    session.setAttribute("message", message);
                    request.getRequestDispatcher("home").forward(request, response);
                } else {
                    ProductDAO product_dao = new ProductDAO();
                    ArrayList<Product> listProduct = product_dao.selectAllBySellerId(user.getId());
                    request.setAttribute("listProduct", listProduct);
                    request.getRequestDispatcher("myProduct.jsp").forward(request, response);
                }

            } else {
                request.getRequestDispatcher("login").forward(request, response);
            }
        } catch (NumberFormatException e) {
            System.out.println(e);
        }
    }

    private void viewAddProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {

            HttpSession session = request.getSession();
            Account user = (Account) session.getAttribute("user");
            if (user != null) {
                

                if (user.getRole().getRoleId() != 2) {
                    String message = "You can't view this screen";
                    session.setAttribute("message", message);
                    request.getRequestDispatcher("home").forward(request, response);
                } else {
                    CategoryDAO category_dao = new CategoryDAO();
                    ArrayList<Category> listCategory = category_dao.selectAll();
                    request.setAttribute("listCategory", listCategory);
                    request.getRequestDispatcher("addProduct.jsp").forward(request, response);
                }

            } else {
                request.getRequestDispatcher("login").forward(request, response);
            }
        } catch (NumberFormatException e) {
            System.out.println(e);
        }
    }

    private void addProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Account user = (Account) session.getAttribute("user");
        if (user != null) {
            
            if (user.getRole().getRoleId() != 2) {
                String message = "You can't view this screen";
                session.setAttribute("message", message);
                request.getRequestDispatcher("home").forward(request, response);
            } else {
                int userID = user.getId();

                String productName = request.getParameter("productName");
                String des = request.getParameter("des");
                String color = request.getParameter("color");
                String originalPrice_string = request.getParameter("originalPrice");
                int originalPrice = Integer.parseInt(originalPrice_string);
                String sellPrice_string = request.getParameter("sellPrice");
                int sellPrice = Integer.parseInt(sellPrice_string);
                String catId_string = request.getParameter("catId");
                int catId = Integer.parseInt(catId_string);
                String amount_string = request.getParameter("amount");
                int amount = Integer.parseInt(amount_string);

                Part filePart = request.getPart("image");
                String imageFileName = filePart.getSubmittedFileName();
                InputStream is = filePart.getInputStream();
                byte[] data = new byte[is.available()];
                is.read(data);

                ProductDAO product_dao = new ProductDAO();
                product_dao.insertProduct(productName, des, color, originalPrice, sellPrice, catId, userID, amount, imageFileName);
                viewMyProduct(request, response);
            }

        } else {
            request.getRequestDispatcher("login").forward(request, response);
        }
    }

    private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {

            HttpSession session = request.getSession();
            Account user = (Account) session.getAttribute("user");
            if (user != null) {               

                if (user.getRole().getRoleId() != 2) {
                    String message = "You can't view this screen";
                    session.setAttribute("message", message);
                    request.getRequestDispatcher("home").forward(request, response);
                } else {
                    String productId_String = request.getParameter("productId");
                    int productId = Integer.parseInt(productId_String);
                    ProductDAO product_dao = new ProductDAO();
                    product_dao.delete(productId);
                    viewMyProduct(request, response);
                }

            } else {
                request.getRequestDispatcher("login").forward(request, response);
            }
        } catch (NumberFormatException e) {
            System.out.println(e);
        }
    }
}
