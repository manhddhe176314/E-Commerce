/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.Account;
import Model.City;
import Model.District;
import Model.ShipAddress;
import java.util.ArrayList;

/**
 *
 * @author Tu
 */
public class ShipAddressDAO extends MyDAO implements DAOInterface<ShipAddress> {

    @Override
    public ArrayList<ShipAddress> selectAll() {
        ArrayList<ShipAddress> t = new ArrayList<>();
        String sql = "SELECT * from ShipAddress";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            /* The cursor on the rs after this statement is in the BOF area, i.e. it is before the first record.
         Thus the first rs.next() statement moves the cursor to the first record
             */
            while (rs.next()) {
                int id = rs.getInt("Id");
                int userId = rs.getInt("userId");
                AccountDAO user_dao = new AccountDAO();
                Account user = user_dao.selectById(userId);

                String fullName = rs.getString("FullName");
                String phoneNum = rs.getString("PhoneNum");

                int cityId = rs.getInt("ShipCityId");
                CityDAO city_dao = new CityDAO();
                City shipCity = city_dao.selectById(cityId);

                int districtId = rs.getInt("DistrictId");
                DistrictDAO district_dao = new DistrictDAO();
                District district = district_dao.selectById(districtId);

                String addressDetail = rs.getString("AddressDetail");

                boolean isUse = rs.getBoolean("isUse");

                ShipAddress x = new ShipAddress(id, user, fullName, phoneNum, shipCity, district, addressDetail, isUse);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return t;
    }

    public ArrayList<ShipAddress> getByUserId(int userID) {
        ArrayList<ShipAddress> t = new ArrayList<>();
        String sql = "select * from ShipAddress where userId = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, userID);
            rs = ps.executeQuery();
            /* The cursor on the rs after this statement is in the BOF area, i.e. it is before the first record.
         Thus the first rs.next() statement moves the cursor to the first record
             */

            while (rs.next()) {
                int id = rs.getInt("Id");

                AccountDAO user_dao = new AccountDAO();
                Account user = user_dao.selectById(userID);
                String fullName = rs.getString("FullName");
                String phoneNum = rs.getString("PhoneNum");

                int cityId = rs.getInt("ShipCityId");
                CityDAO city_dao = new CityDAO();
                City shipCity = city_dao.selectById(cityId);

                int districtId = rs.getInt("DistrictId");
                DistrictDAO district_dao = new DistrictDAO();
                District district = district_dao.selectById(districtId);

                String addressDetail = rs.getString("AddressDetail");

                boolean isUse = rs.getBoolean("isUse");

                ShipAddress x = new ShipAddress(id, user, fullName, phoneNum, shipCity, district, addressDetail, isUse);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
        }
        return t;
    }

    @Override
    public ShipAddress selectById(int id) {
        ShipAddress ketqua = null;
        String sql = "select * from ShipAddress where Id = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            /* The cursor on the rs after this statement is in the BOF area, i.e. it is before the first record.
         Thus the first rs.next() statement moves the cursor to the first record
             */

            if (rs.next()) {
                 int userId = rs.getInt("userId");
                 AccountDAO user_dao = new AccountDAO();
                 Account user = user_dao.selectById(userId);
                 
                 String fullName = rs.getString("FullName");
                 String phoneNum = rs.getString("PhoneNum");
                 
                 int cityId = rs.getInt("ShipCityId");
                 CityDAO city_dao = new CityDAO();
                 City shipCity = city_dao.selectById(cityId);
                 
                 int districtId = rs.getInt("DistrictId");
                 DistrictDAO district_dao = new DistrictDAO();
                 District district = district_dao.selectById(districtId);
                 
                 String addressDetail = rs.getString("AddressDetail");
                 
                 boolean isUse = rs.getBoolean("isUse");
                 

                ketqua = new ShipAddress(id, user, fullName, phoneNum, shipCity, district, addressDetail,isUse);
            } else {
                ketqua = null;
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
        }
        return (ketqua);
    }

    @Override
    public void insert(ShipAddress t) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int insertAll(ArrayList<ShipAddress> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int deleteAll(ArrayList<ShipAddress> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        ShipAddressDAO dao = new ShipAddressDAO();
        System.out.println(dao.selectById(2));
    }

}
