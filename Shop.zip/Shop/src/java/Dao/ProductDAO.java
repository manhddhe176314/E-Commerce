/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.Account;
import Model.Category;
import Model.Product;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Tu
 */
public class ProductDAO extends MyDAO implements DAOInterface<Product> {

    @Override
    public ArrayList<Product> selectAll() {
        ArrayList<Product> t = new ArrayList<>();
        String sql = "select * from Product";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int productID = rs.getInt("ProductID");
                String productName = rs.getString("ProductName");
                String description = rs.getString("Description");
                String color = rs.getString("color");
                int originalPrice = rs.getInt("OriginalPrice");
                int sellPrice = rs.getInt("SellPrice");

                int catId = rs.getInt("CatID");
                CategoryDAO cat_dao = new CategoryDAO();
                Category category = cat_dao.selectById(catId);

                int seller_id = rs.getInt("SellerID");

                AccountDAO dao = new AccountDAO();
                Account seller = dao.selectById(seller_id);

                int amount = rs.getInt("Amount");

                String imgLink = rs.getString("ImgLink");

                Product y = new Product(productID, productName, description, color, originalPrice, sellPrice, category, seller, amount, imgLink);
                t.add(y);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    @Override
    public Product selectById(int id) {
        Product ketqua = null;
        String sql = "select * from Product where ProductID = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            /* The cursor on the rs after this statement is in the BOF area, i.e. it is before the first record.
         Thus the first rs.next() statement moves the cursor to the first record
             */

            if (rs.next()) {
                int productID = rs.getInt("ProductID");
                String productName = rs.getString("ProductName");
                String description = rs.getString("Description");
                String color = rs.getString("color");
                int originalPrice = rs.getInt("OriginalPrice");
                int sellPrice = rs.getInt("SellPrice");

                int catId = rs.getInt("CatID");
                CategoryDAO cat_dao = new CategoryDAO();
                Category category = cat_dao.selectById(catId);

                int seller_id = rs.getInt("SellerID");

                AccountDAO dao = new AccountDAO();
                Account seller = dao.selectById(seller_id);

                int amount = rs.getInt("Amount");

                String imgLink = rs.getString("ImgLink");

                ketqua = new Product(productID, productName, description, color, originalPrice, sellPrice, category, seller, amount, imgLink);
            } else {
                ketqua = null;
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
        }
        return (ketqua);
    }

    public ArrayList<Product> selectAllByCatId(int catId) {
        ArrayList<Product> t = new ArrayList<>();
        String sql = "select * from Product where CatID = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, catId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int productID = rs.getInt("ProductID");
                String productName = rs.getString("ProductName");
                String description = rs.getString("Description");
                String color = rs.getString("color");
                int originalPrice = rs.getInt("OriginalPrice");
                int sellPrice = rs.getInt("SellPrice");

                CategoryDAO cat_dao = new CategoryDAO();
                Category category = cat_dao.selectById(catId);

                int seller_id = rs.getInt("SellerID");

                AccountDAO dao = new AccountDAO();
                Account seller = dao.selectById(seller_id);

                int amount = rs.getInt("Amount");

                String imgLink = rs.getString("ImgLink");

                Product y = new Product(productID, productName, description, color, originalPrice, sellPrice, category, seller, amount, imgLink);
                t.add(y);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public ArrayList<Product> selectAllBySellerId(int userId) {
        ArrayList<Product> t = new ArrayList<>();
        String sql = "select * from Product where SellerID = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int productID = rs.getInt("ProductID");
                String productName = rs.getString("ProductName");
                String description = rs.getString("Description");
                String color = rs.getString("color");
                int originalPrice = rs.getInt("OriginalPrice");
                int sellPrice = rs.getInt("SellPrice");

                int catId = rs.getInt("CatID");
                CategoryDAO cat_dao = new CategoryDAO();
                Category category = cat_dao.selectById(catId);

                int seller_id = rs.getInt("SellerID");

                AccountDAO dao = new AccountDAO();
                Account seller = dao.selectById(seller_id);

                int amount = rs.getInt("Amount");

                String imgLink = rs.getString("ImgLink");

                Product y = new Product(productID, productName, description, color, originalPrice, sellPrice, category, seller, amount, imgLink);
                t.add(y);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    public void insertProduct(String productName, String desc, String color,
            int originalPrice, int sellPrice, int catId, int sellerId,
            int amount, String imgLink) {
        try {
            String sql = "Insert into Product ([ProductName]\n"
                    + "           ,[Description]\n"
                    + "           ,[color]\n"
                    + "           ,[OriginalPrice]\n"
                    + "           ,[SellPrice]\n"
                    + "           ,[CatID]\n"
                    + "           ,[SellerID]\n"
                    + "           ,[Amount]\n"
                    + "           ,[ImgLink]) values(?,?,?,?,?,?,?,?,?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, productName);
            ps.setString(2, desc);
            ps.setString(3, color);
            ps.setInt(4, originalPrice);
            ps.setInt(5, sellPrice);
            ps.setInt(6, catId);
            ps.setInt(7, sellerId);
            ps.setInt(8, amount);
            ps.setString(9, imgLink);
            ps.executeUpdate();
        } catch (SQLException e) {
        }
    }

    @Override
    public void insert(Product t) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int insertAll(ArrayList<Product> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) {
        try {
            String sql = "DELETE FROM Product WHERE ProductID = (?)";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    @Override
    public int deleteAll(ArrayList<Product> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        ProductDAO dao = new ProductDAO();

        for (Product product : dao.selectAll()) {
            System.out.println(product);
        }
    }

}
