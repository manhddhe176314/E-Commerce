/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.Account;
import Model.Role;
import java.util.ArrayList;

/**
 *
 * @author Tu
 */
public class AccountDAO extends MyDAO implements DAOInterface<Account> {

    @Override
    public ArrayList<Account> selectAll() {
        ArrayList<Account> t = new ArrayList<>();
        String sql = "select * from Account";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("Id");
                String userName = rs.getString("Username");
                String password = rs.getString("Password");
                String email = rs.getString("Email");
                String phoneNum = rs.getString("PhoneNum");
                int role_id = rs.getInt("RoleID");

                RoleDAO dao = new RoleDAO();
                Role role = dao.selectById(role_id);

                Account x = new Account(id, userName, password, email, phoneNum, role);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    @Override
    public Account selectById(int id) {
        Account ketqua = null;
        String sql = "select * from Account where Id = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            /* The cursor on the rs after this statement is in the BOF area, i.e. it is before the first record.
         Thus the first rs.next() statement moves the cursor to the first record
             */

            if (rs.next()) {
                String userName = rs.getString("Username");
                String password = rs.getString("Password");
                String email = rs.getString("Email");
                String phoneNum = rs.getString("PhoneNum");
                int role_id = rs.getInt("RoleID");

                RoleDAO dao = new RoleDAO();
                Role role = dao.selectById(role_id);

                ketqua = new Account(id, userName, password, email, phoneNum, role);

            } else {
                ketqua = null;
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
        }
        return (ketqua);
    }
    
    public Account login(String user, String pass) {

        try {
            String sql = "SELECT Id , Username , Password , Email,PhoneNum , RoleID from Account  \n"
                    + "where Username = ? and Password = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            while (rs.next()) {

                int userId = rs.getInt("Id");
                String userName = rs.getString("Username");
                String password = rs.getString("Password");
                String email = rs.getString("Email");
                String phoneNum = rs.getString("PhoneNum");
                int role_id = rs.getInt("RoleID");

                RoleDAO dao = new RoleDAO();
                Role role = dao.selectById(role_id);

                return new Account(userId, userName, password, email, phoneNum, role);
            }
        } catch (Exception e) {
        }
        return null;
    }
    
    public Account checkUserExist(String user) {

       try {
            String sql = "SELECT Id , Username , Password , Email,PhoneNum , RoleID from Account  \n"
                    + "where Username = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, user);
            
            rs = ps.executeQuery();
            while (rs.next()) {

                int userId = rs.getInt("Id");
                String userName = rs.getString("Username");
                String password = rs.getString("Password");
                String email = rs.getString("Email");
                String phoneNum = rs.getString("PhoneNum");
                int role_id = rs.getInt("RoleID");

                RoleDAO dao = new RoleDAO();
                Role role = dao.selectById(role_id);

                return new Account(userId, userName, password, email, phoneNum, role);
            }
        } catch (Exception e) {
        }
        return null;
    }
    
    public Account checkEmailExist(String email) {

         try {
            String sql = "SELECT Id , Username , Password , Email,PhoneNum , RoleID from Account \n"
                    + "where Email = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, email);
            
            rs = ps.executeQuery();
            while (rs.next()) {

                int userId = rs.getInt("Id");
                String userName = rs.getString("Username");
                String password = rs.getString("Password");
                String phoneNum = rs.getString("PhoneNum");
                int role_id = rs.getInt("RoleID");

                RoleDAO dao = new RoleDAO();
                Role role = dao.selectById(role_id);

                return new Account(userId, userName, password, email, phoneNum, role);
            }
        } catch (Exception e) {
        }
        return null;
    }
    
    public void register(Account u) {
        try {
            String sql = "insert into Account values (? , ? , ? , ? , 1)";
            ps = con.prepareStatement(sql);
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getPhoneNum());
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    @Override
    public void insert(Account t) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int insertAll(ArrayList<Account> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int deleteAll(ArrayList<Account> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public static void main(String[] args) {
        AccountDAO dao = new AccountDAO();
        
//        for (Account account : dao.selectAll()) {
//            System.out.println(account);
//        }
        
        dao.register(new Account(2, "diep", "123456", "diep123@gmail.com", "0962239815", null));
    }
    
}
