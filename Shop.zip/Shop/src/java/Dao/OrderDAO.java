/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.Account;
import Model.Order;
import Model.OrderStatus;
import Model.ShipAddress;
import java.util.ArrayList;

/**
 *
 * @author Tu
 */
public class OrderDAO extends MyDAO implements DAOInterface<Order> {

    @Override
    public ArrayList<Order> selectAll() {
        ArrayList<Order> t = new ArrayList<>();
        String sql = "select * from [Order]";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                int userId = rs.getInt("UserID");
                AccountDAO user_dao = new AccountDAO();
                Account user = user_dao.selectById(userId);

                int totalPrice = rs.getInt("TotalPrice");
                String note = rs.getString("Note");

                int shipId = rs.getInt("ShipId");
                ShipAddressDAO shipAddress_dao = new ShipAddressDAO();
                ShipAddress shipAddress = shipAddress_dao.selectById(shipId);

                int orderStatusId = rs.getInt("StatusID");
                OrderStatusDAO orderStatus_dao = new OrderStatusDAO();
                OrderStatus orderStatus = orderStatus_dao.selectById(orderStatusId);

                String OrderDate = rs.getString("OrderDate");
                String DeliveryDate = rs.getString("DeliveryDate");

                Order x = new Order(id, user, totalPrice, note, shipAddress, orderStatus, OrderDate, DeliveryDate);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    @Override
    public Order selectById(int id) {
        Order ketqua = null;
        String sql = "select * from Order where ID = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            /* The cursor on the rs after this statement is in the BOF area, i.e. it is before the first record.
         Thus the first rs.next() statement moves the cursor to the first record
             */

            if (rs.next()) {
                int userId = rs.getInt("UserID");
                AccountDAO user_dao = new AccountDAO();
                Account user = user_dao.selectById(userId);

                int totalPrice = rs.getInt("TotalPrice");
                String note = rs.getString("Note");

                int shipId = rs.getInt("ShipId");
                ShipAddressDAO shipAddress_dao = new ShipAddressDAO();
                ShipAddress shipAddress = shipAddress_dao.selectById(shipId);

                int orderStatusId = rs.getInt("StatusID");
                OrderStatusDAO orderStatus_dao = new OrderStatusDAO();
                OrderStatus orderStatus = orderStatus_dao.selectById(orderStatusId);

                String OrderDate = rs.getString("OrderDate");
                String DeliveryDate = rs.getString("DeliveryDate");

                ketqua = new Order(id, user, totalPrice, note, shipAddress, orderStatus, OrderDate, DeliveryDate);
            } else {
                ketqua = null;
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
        }
        return (ketqua);
    }

    @Override
    public void insert(Order t) {
        String sql = "insert into [Order] (UserID,TotalPrice,Note,ShipId,StatusID,OrderDate,DeliveryDate) values (?,?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, t.getUser().getId());
            ps.setInt(2, t.getTotalPrice());
            ps.setString(3, t.getNote());
            ps.setInt(4, t.getShipaddress().getId());
            ps.setInt(5, t.getStatus().getId());
            ps.setString(6, t.getOrderDate());
            ps.setString(7, t.getDeliveryDate());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Order> selectAllByUserId(int userId) {
        ArrayList<Order> t = new ArrayList<>();
        String sql = "select * from [Order] where UserID = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                AccountDAO user_dao = new AccountDAO();
                Account user = user_dao.selectById(userId);

                int totalPrice = rs.getInt("TotalPrice");
                String note = rs.getString("Note");

                int shipId = rs.getInt("ShipId");
                ShipAddressDAO shipAddress_dao = new ShipAddressDAO();
                ShipAddress shipAddress = shipAddress_dao.selectById(shipId);

                int orderStatusId = rs.getInt("StatusID");
                OrderStatusDAO orderStatus_dao = new OrderStatusDAO();
                OrderStatus orderStatus = orderStatus_dao.selectById(orderStatusId);

                String OrderDate = rs.getString("OrderDate");
                String DeliveryDate = rs.getString("DeliveryDate");

                Order x = new Order(id, user, totalPrice, note, shipAddress, orderStatus, OrderDate, DeliveryDate);
                t.add(x);
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (t);
    }

    @Override
    public int insertAll(ArrayList<Order> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int deleteAll(ArrayList<Order> arr) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        OrderDAO dao = new OrderDAO();

//        AccountDAO account_dao = new AccountDAO();
//        Account user = account_dao.selectById(1);
//        ShipAddressDAO shipaddress_dao = new ShipAddressDAO();
//        ArrayList<ShipAddress> shipaddress = shipaddress_dao.getByUserId(user.getId());
//        OrderStatusDAO status_dao = new OrderStatusDAO();
//        OrderStatus status = status_dao.selectById(1);
//        Order order = new Order(1, user, 400, "hi", shipaddress.get(0), status, "22-02-2023 08:23", "23-02-2023 08:23");
//        dao.insert(order);
//        for (Order s : dao.selectAll()) {
//            System.out.println(s);
//        }
        for (Order order : dao.selectAllByUserId(1)) {
            System.out.println(order);
        }

    }
}
