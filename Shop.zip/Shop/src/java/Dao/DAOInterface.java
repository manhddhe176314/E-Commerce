/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Dao;

import java.util.ArrayList;

/**
 *
 * @author Tu
 * @param <T>
 */
public interface DAOInterface<T> {

    public ArrayList<T> selectAll();

    public T selectById(int id);

    /**
     *
     * @param t
     */
    public void insert(T t);

    public int insertAll(ArrayList<T> arr);

    /**
     *
     * @param id
     */
    public void delete(int id);

    public int deleteAll(ArrayList<T> arr);

    /**
     *
     * @param id
     */
    public void update(int id);
}
